PyXLL Stubs Module
==================

The PyXLL stubs module is a support module for the PyXLL Excel addin.

It implements the same functions as the pyxll module built-in to the
PyXLL addin to allow code referencing that module to be usable outside
of Excel (e.g. when unit testing).

For full documentation and support please visit https://www.pyxll.com.
